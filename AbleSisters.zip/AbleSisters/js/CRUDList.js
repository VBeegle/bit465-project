let apiurl = 'https://fdjlrcueqe.execute-api.us-west-2.amazonaws.com/dev/AbleSistersFunction';
let myData = [];
console.log(myData);

async function getAll() {
    myData = await fetch(apiurl+'/clothing/')
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        return appendData(data);
    });
    console.log(myData);
    document.getElementById('display').innerHTML = myData;   
}
                
function appendData(data) {
    myData = [];
    console.log(myData);
    console.log(data);
    let range = document.createRange();
    range.selectNodeContents(document.getElementById('images'));
    range.deleteContents();
    if (data.length != null){
        for (var i = 0; i < data.length; i++) {myData[i] = 
            'ID: ' + data[i].id + 
            ', Name: ' + data[i].name +
            ', Category: '+ data[i].category + 
            ', Date: '+ data[i].date +
            ', Price: $'+ data[i].price +
            ', Seasonal: '+ data[i].seasonal +
            ', Tabletop Item: '+ data[i].tabletop_item +
            ', Image URL: '+ data[i].image +
            '<br>';
            let img = document.createElement('img'); 
            img.src = "images/"+data[i].image; 
            img.id = "img"+i;
            let thisID = data[i].id;
            img.onclick = function() {goToDetail(thisID)};
            document.getElementById('images').appendChild(img); 
            console.log(myData);
        }
    }
    console.log(myData);
    return myData;
}

function goToDetail(id){
    sessionStorage.setItem("detailID", id);
    window.location.href = 'Clothing.html';
}

async function getOne(id) {
    await fetch(apiurl+'/clothing/'+id)
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        console.log(data);
        document.getElementById("txtID").value = data.id;
        document.getElementById("txtName").value = data.name;
        document.getElementById("txtCategory").value = data.category;
        document.getElementById("txtDate").value = data.date;
        document.getElementById("txtPrice").value = data.price;
        document.getElementById("txtSeasonal").value = data.seasonal;
        document.getElementById("txtTabletop").value = data.tabletop_item;
        let myData =         
        'ID: ' + data.id + 
        ', Name: ' + data.name +
        ', Category: '+ data.category + 
        ', Date: '+ data.date +
        ', Price: $'+ data.price +
        ', Seasonal: '+ data.seasonal +
        ', Tabletop Item: '+ data.tabletop_item +
        ', Image URL: '+ data.image;
        let range = document.createRange();
        range.selectNodeContents(document.getElementById('image'));
        range.deleteContents();
        let img = document.createElement('img'); 
        img.src = "images/"+data.image; 
        img.id = "img";
        document.getElementById('image').appendChild(img); 
        document.getElementById('display').innerHTML = myData;  
    });
}

function postOne(postid, postname, postcategory, postdate, postprice, postseasonal, posttabletop, postimage) {

    console.log(postid, postname, postcategory, postdate, postprice, postseasonal, posttabletop, postimage);
    return fetch(apiurl+'/clothing/', {
        method: 'POST',
        body: JSON.stringify({ id: postid, name: postname, category: postcategory, date: postdate, price: postprice, seasonal: postseasonal, tabletop_item: posttabletop, image: postimage}), 
        headers: { "Content-type": "application/json; charset=UTF-8" } }) 
        .then(response => response.json()) 
        .then(json => console.log(json))
}

function numOutput(){
    var inputVal = parseInt(document.getElementById("txtID").value);
    if (isNaN(inputVal) || inputVal <= 0){ 
    alert("Please input a number greater than 0"); 
    throw new Error("Number Input Required");
    }
    else{
        return inputVal
    }
}

function signOut(){
    sessionStorage.setItem("didSignIn", false);
    location.reload();
}

function userOutput(){
    var inputID = numOutput();
    var inputName = document.getElementById("txtName").value;
    var inputCategory = document.getElementById("txtCategory").value;
    var inputDate = document.getElementById("txtDate").value;
    var inputPrice = parseFloat(document.getElementById("txtPrice").value);
    var inputSeasonal = document.getElementById("txtSeasonal").value;
    var inputTabletop = document.getElementById("txtTabletop").value;
    var inputImage = document.getElementById('fileImage').files[0];

    if (
    inputName == "" || 
    inputCategory == "" || 
    inputDate == "" || 
    inputPrice == "" || 
    inputSeasonal == "" || 
    inputTabletop == ""){
        alert("Do not leave any fields empty!"); 
        throw new Error("empty input");
    }
    if (isNaN(inputPrice) || inputPrice <= 0){
        alert("Please input a valid price"); 
        throw new Error("invalid price");
    }
    if (inputSeasonal != "true" && inputSeasonal != "false"){
        alert("Please input a valid boolean"); 
        throw new Error("invalid boolean");
    }
    if (inputTabletop != "true" && inputTabletop != "false"){
        alert("Please input a valid boolean"); 
        throw new Error("invalid boolean");
    }

    if(inputImage == null){
        alert("Please upload a file"); 
        throw new Error("empty input");
    }
    else{
        inputImage = inputImage.name;
        let inputSeasonalBool = (inputSeasonal == "true");
        let inputTabletopBool = (inputTabletop == "true");
        let arr = [inputID, inputName, inputCategory, inputDate, inputPrice, inputSeasonalBool, inputTabletopBool, inputImage];
        console.log(arr);
        return arr;
    }   

}

function postOutput(){
    let arr = userOutput();
    console.log(arr);
    postOne(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7]);
    alert("Post successful!"); 
    getAll();
    window.location.reload();
}

function putOutput(){
    let arr = userOutput();
    console.log(arr);
    updateOne(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7]);
    alert("Update successful!"); 
    getOne(arr[0])
    window.location.reload();
}

function deleteOutput(id){
    deleteOne(id);
}

function updateOne(postid, postname, postcategory, postdate, postprice, postseasonal, posttabletop, postimage){

    console.log(JSON.stringify({ id: postid, name: postname, category: postcategory, date: postdate, price: postprice, seasonal: postseasonal, tabletop_item: posttabletop, image: postimage}))
    console.log(postid, postname, postcategory, postdate, postprice, postseasonal, posttabletop, postimage);
    return fetch(apiurl+'/clothing/'+postid+'/', {
        method: 'PUT',
        body: JSON.stringify({ id: postid, name: postname, category: postcategory, date: postdate, price: postprice, seasonal: postseasonal, tabletop_item: posttabletop, image: postimage}), 
        headers: { "Content-type": "application/json; charset=UTF-8" } }) 
        .then(response => response.json()) 
        .then(json => console.log(json))

}

function deleteOne(id) {

    alert("Delete successful!\r\nPlease return to Home page or reload.");
    return fetch(apiurl+'/clothing/'+id+'/', {
        method: 'DELETE'
    }) 
        .then(response => response.json()) 
        .then(json => console.log(json))
}


