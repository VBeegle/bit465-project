apiurl = 'https://fdjlrcueqe.execute-api.us-west-2.amazonaws.com/dev/AbleSistersFunction';
myData = [];
console.log(myData);
       
function appendData(data) {
    myData = [];
    console.log(myData);
    console.log(data.token, data.username, data.password);
    myData = [data.token, data.username, data.password];
    console.log(myData);
    return myData;
}


async function getOne() {
    let arr1 = signInOutput();
    console.log(arr1[0]);
    let arr2 = await fetch(apiurl+'/login/'+arr1[0])
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        return appendData(data);
    });
    console.log(arr2);
    if (arr2[0] == null || arr2[0] != arr1[0]){
        alert("Username or Password is incorrect!")
        throw new Error("invalid credentials");
    }
    else{
        alert("Signin Complete!")
        sessionStorage.setItem("didSignIn", true);
        window.location.href = 'Index.html';
    }
}

function userRegister(){
    let arr = registerOutput();
    console.log(arr);
    postOne(arr[0], arr[1], arr[2]);
    alert("Registration Complete!")
    window.location.href = 'signin.html';
}

function postOne(posttoken, postusername, postpassword) {

    return fetch(apiurl+'/login/', {
        method: 'POST',
        body: JSON.stringify({ token: posttoken, username: postusername, password: postpassword}), 
        headers: { "Content-type": "application/json; charset=UTF-8" } }) 
        .then(response => response.json()) 
        .then(json => console.log(json))
}


function registerOutput(){
    var inputUsername = document.getElementById("txtEmail").value;
    var inputPassword = document.getElementById("txtPassword").value;
    var inputToken = inputUsername + inputPassword;
    if (
        inputUsername == "" || 
        inputPassword == ""){
            alert("Do not leave any fields empty!"); 
            throw new Error("empty input");
        }

    let arr = [inputToken, inputUsername, inputPassword];
    return arr;
}

function signInOutput(){
    var inputUsername = document.getElementById("txt2Email").value;
    var inputPassword = document.getElementById("txt2Password").value;
    var inputToken = inputUsername + inputPassword;
    if (
        inputUsername == "" || 
        inputPassword == ""){
            alert("Do not leave any fields empty!"); 
            throw new Error("empty input");
        }

    let arr = [inputToken, inputUsername, inputPassword];
    console.log(arr);
    return arr;
}



